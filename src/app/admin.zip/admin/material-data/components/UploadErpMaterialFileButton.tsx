// admin/material-data/components/UploadErpMaterialFileButton.tsx
"use client";

import { FC, useRef } from "react";
import { Button, ButtonProps } from "@mui/material";
import { UploadCloud } from "lucide-react";

export interface UploadErpMaterialFileButtonProps {
  saleOrderNumber: string;
  onCreated: () => void;
  buttonProps?: ButtonProps;
  /** When provided, clicking the button will open your dialog instead of hidden file input */
  onOpenDialog?: () => void;
}

const UploadErpMaterialFileButton: FC<UploadErpMaterialFileButtonProps> = ({
  saleOrderNumber,
  onCreated,
  buttonProps,
  onOpenDialog,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const openPicker = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (onOpenDialog) {
      onOpenDialog(); // <-- open the dialog when parent wants it
      return;
    }
    // fallback to old behavior if no dialog is supplied
    inputRef.current?.click();
  };

  const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // your existing upload flow here (left as-is)
    // await uploadFile(file, saleOrderNumber);
    onCreated();
    e.target.value = "";
  };

  return (
    <>
      {/* kept to preserve existing behavior for other pages */}
      <input ref={inputRef} type="file" hidden onChange={onFileChange} />

      <Button
        type="button"
        onClick={openPicker}
        startIcon={<UploadCloud size={18} />}
        disableElevation
        sx={[
          (theme) => ({
            color: theme.palette.text.primary,
            "&:hover": { backgroundColor: theme.palette.action.hover },
            borderRadius: 0,
            minHeight: 40,
            whiteSpace: "nowrap",
            px: 2,
            "& .MuiButton-startIcon": { mr: 1 },
            minWidth: 112,
          }),
          buttonProps?.sx as any,
        ]}
        {...buttonProps}
      >
        Upload
      </Button>
    </>
  );
};

export default UploadErpMaterialFileButton;
